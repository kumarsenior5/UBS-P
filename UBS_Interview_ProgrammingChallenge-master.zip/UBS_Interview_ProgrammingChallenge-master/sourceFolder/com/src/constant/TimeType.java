package com.src.constant;

/*
 * Decides which component to call while process the original time
 * 
 * */
/**
 * @author Prashant
 *
 */
public enum TimeType {
	HOUR, MINUTE
}
